﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using College.Infrastructure.Applications.AppTracker;

namespace Email_Sender
{
    interface ILogger
    {
        int TrackerAppId { get; }
        string ApplicationName { get; }
        int ProcessId { get; }
        void logger(string description);
        void logger(Logs.ApplicationLogEntryTypes stept, string description);
        void audit(string description);
        void exception(Exception Ex);

    }

    interface IJob
    {
        void Execute();
    }

    interface IDataProvider
    {
        string SOAPActionUrl
        {
            get;
            
        }
        string HttpWebRequestUrl
        {
            get;
            
        }


        IEnumerable<WorkItem> GetUnsentLockedMessagesRSInner();
        IEnumerable<WorkItem> GetUnsentMessagesRS();   
        void MarkMessageAsSent(int messageId);

       

    }


}
