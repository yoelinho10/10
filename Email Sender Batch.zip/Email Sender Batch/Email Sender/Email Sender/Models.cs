﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using College.Infrastructure.Applications.AppTracker;
using College;
using College.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Email_Sender
{
    public class WorkItem
    {
        public int MessageID { get; set; }
        public string CCRecipient { get; set; }
        public string BCCRecipient { get; set; }
        public string Subject { get; set; }
        public bool QuotedPrintableMessage { get; set; }
        public string Sender
        {
            get { return _sender.Replace("<", string.Empty).Replace(">", string.Empty);}
        }
        public string _sender { get; set; }
        public string Recipient { get; set; }
        public string Message { get; set; }
        private int _priority { get; set; }
        public int HTMLFormatted { get; set; }
        public string ProcessId { get; set; }
        public string Priority
        {
            get
            {
                switch (_priority)
                {
                    case 1:
                        return "nsNormalPriority";
                        
                    case 2:
                        return "nsAboveNormalPriority";                        

                    default:
                        return "nsBelowNormalPriority";
                        
                }
            }
        }


        public WorkItem(int Messageid, string cCRecipient, string bCCRecipient, string subject, bool quotedPrintableMessage, string sender, string recipient, string message, int priority/*, int hTMLFormatted*/)
        {
            MessageID = Messageid;
            CCRecipient = cCRecipient;
            BCCRecipient = bCCRecipient;
            Subject = subject;
            QuotedPrintableMessage = quotedPrintableMessage;
            _sender = sender;
            Recipient = recipient;
            Message = message;
            _priority = priority;
            //HTMLFormatted = hTMLFormatted;            
        }
        
        public WorkItem()
        {
        }

        public WorkItem(int Messageid)
        {
            MessageID = Messageid;
        }
    }

    public static class Extensions
    {

        public static bool IsNullOrEmpty<T>(this IEnumerable<T> enumerable)
        {
            return enumerable == null || !enumerable.Any();
        }

      
        public static T GetFieldValueOrDefault<T>(this SqlDataReader reader, string name)
        {
            int index = reader.GetOrdinal(name);
            T value = reader.IsDBNull(index) ? default(T) : reader.GetFieldValue<T>(index);
            return value;
        }
    }

    public class Logger : ILogger
    {
        private readonly string _ApplicationName = "NotificationSystemEmailSender";

        private const int _TrackerAppId = 8; //AppTracker id differente del ApplicationConfigurationId

        private readonly int _ProcessId = Utilities.GenerateProcessID();

        public int TrackerAppId
        {
            get
            {
                return _TrackerAppId;
            }
        }
        public string ApplicationName
        {
            get
            {
                return _ApplicationName;
            }
        }

        public int ProcessId
        {
            get
            {
                return _ProcessId;
            }
        }

        public void logger(string description)
        {
            Logs.LogApplicationEvent(TrackerAppId, ProcessId, Logs.ApplicationLogEntryTypes.atInformation, 0, description);
        }

        public void logger (Logs.ApplicationLogEntryTypes stept, string description)
        {
            Logs.LogApplicationEvent(TrackerAppId, ProcessId, stept, 0, description);
        }

        public void audit(string description)
        {
            Audit.AuditApplicationEvent(TrackerAppId, ProcessId, Audit.AuditLogEntryTypes.atAuditInformation, ApplicationName, 0, description);
        }

        public void exception(Exception Ex)
        {
            College.ExceptionTools.HandleException(false, Ex);
        }

    }


}
