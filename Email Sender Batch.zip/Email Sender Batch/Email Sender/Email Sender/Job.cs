﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using College.Infrastructure.Applications.AppTracker;
using System.Xml;
using System.Net;
using System.IO;

namespace Email_Sender
{
    class Job : IJob
    {
        protected readonly IDataProvider _provider;

        protected readonly ILogger _logger;

        private string HttpWebRequestUrl { get { return _provider.HttpWebRequestUrl; } }
        private string SOAPActionUrl { get { return _provider.SOAPActionUrl; } }

        public Job(IDataProvider provider, ILogger logger)
        {
            _provider = provider;
            _logger = logger;
        }
        public Job()
        {

        }

        public void Execute()
        {
            try
            {
                _logger.logger(Logs.ApplicationLogEntryTypes.atInformation, "ManagedDistributionListPopulator Proccess Init");
                
                ProcessUnsentLockedEmailMessages();

                ProcessPendingEmailMessages();

                _logger.logger(Logs.ApplicationLogEntryTypes.atProcessSuccess, "ManagedDistributionListPopulator sucessfully completed");
            }
            catch (Exception e)
            {
                _logger.logger("Generic exception failure");
                throw new Exception(e.Message);
            }

        }
        

        private void ProcessUnsentLockedEmailMessages()
        {
            try
            {               
                var UnsentLockedMessagesRS = _provider.GetUnsentLockedMessagesRSInner();

                _logger.logger("Sucessfully loaded " + UnsentLockedMessagesRS.Count() + "items from email table");

                foreach (var message in UnsentLockedMessagesRS)
                {
                    SendEmailMessage(message.MessageID, message.Sender, message.Recipient, message.CCRecipient, message.BCCRecipient, message.Subject, message.Message, message.Priority, message.QuotedPrintableMessage);
                    _logger.logger("Sucessfully sent email with message id " + message.MessageID + "from email table");
                    MarkMessageAsSent(message.MessageID);
                }
                //}
            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure ProcessUnsentLockedEmailMessages()");
                _logger.exception(ex);
                throw new Exception(ex.Message);
            }
            


        }

        private void SendEmailMessage(int messageID, string sender, string recipient, string cCRecipient, string bCCRecipient, string subject, string message, string priority, bool quotedPrintableMessage)
        {
              
            try
            {
                HttpWebRequest request = CreateSOAPWebRequest();
                XmlDocument SOAPReqBody = new XmlDocument();
                //SOAP Body Request
                SOAPReqBody.LoadXml(@"<?xml version=""1.0"" encoding=""utf-8""?>
            <soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
             <soap:Body>                
                <SendEmail_Overload4 xmlns=""https://wapi.mdc.edu/College.Infrastructure.Webservices.Mail/"">
                <Recipients>
                <string>" + recipient + @"</string>
                <string>" + recipient + @"</string>
                </Recipients>
                <MessageBody>" + message + @"</MessageBody>
                <Subject>" + subject + @"</Subject>
                <Sender>" + sender + @"</Sender>
                <Priority>" + priority + @"</Priority>
                <CCRecipients>
                <string>" + cCRecipient + @"</string>
                <string>" + cCRecipient + @"</string>
                </CCRecipients>
                <BCCRecipients>
                <string>" + bCCRecipient + @"</string>
                <string>" + bCCRecipient + @"</string>
                </BCCRecipients>
                </SendEmail_Overload4>
              </soap:Body>
            </soap:Envelope>");

                using (Stream stream = request.GetRequestStream())
                {
                    SOAPReqBody.Save(stream);
                }
                //Geting response from request
                using (WebResponse Serviceres = request.GetResponse())
                {
                    using (StreamReader rd = new StreamReader(Serviceres.GetResponseStream()))
                    {
                        //reading stream
                        var ServiceResult = rd.ReadToEnd();
                       
                        
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure SendEmailMessage()"+ messageID + "message Id" + ex.Message);                
                throw new Exception(ex.Message);
            }           
        }
    
        public HttpWebRequest CreateSOAPWebRequest()
        {
            try
            {
                //Making Web Request
                HttpWebRequest Req = (HttpWebRequest)WebRequest.Create(@HttpWebRequestUrl);
                //SOAPAction
                Req.Headers.Add(@"SOAPAction:"+SOAPActionUrl);
                //Content_type
                Req.ContentType = "text/xml;charset=\"utf-8\"";
                Req.Accept = "text/xml";
                //HTTP method
                Req.Method = "POST";
                //return HttpWebRequest
                return Req;
            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure CreateSOAPWebRequest()" + ex.Message);
                throw new Exception(ex.Message);
            }            
           
        }

        private void ProcessPendingEmailMessages()
        {
           
            try
            {
                var UnsentMessagesRS = _provider.GetUnsentMessagesRS();

                foreach (var item in UnsentMessagesRS)
                {
                    SendEmailMessage(item.MessageID, item.Sender, item.Recipient, item.CCRecipient, item.BCCRecipient, item.Subject, item.Message, item.Priority, item.QuotedPrintableMessage);
                    _logger.logger("Sucessfully sent email with message id " + item.MessageID + "from email table");
                    MarkMessageAsSent(item.MessageID);
                }
            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure ProcessPendingEmailMessages()" + ex.Message);
                throw new Exception(ex.Message);                
            }
           
        }

        private void MarkMessageAsSent(int messageId)
        {
            try
            {
                _provider.MarkMessageAsSent(messageId);
            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure CreateSOAPWebRequest()" + ex.Message);
                throw new Exception(ex.Message);
            }
           
        }
    }
}
