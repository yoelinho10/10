﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using College.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Email_Sender
{
    class DataProvider:IDataProvider
    {
        private const int ConfigurationAppId = 245; //ApplicationConfigurationId aunj por crear en el webapp

        private string _adsFilter;

        private string _connectionString;

        private string _HttpWebRequestUrl;

        private string _SOAPActionUrl;
        public string connectionString
        {
            get
            {
                try
                {
                    _connectionString = ApplicationConfigurations.GetConfigurationValue(ConfigurationAppId, "ConnectionString");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);

                }

                return _connectionString;
            }

        }      

        public string AdsFilter
        {
            get
            {
                try
                {
                    _adsFilter = ApplicationConfigurations.GetConfigurationValue(ConfigurationAppId, "AdsFilter");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }

                return _adsFilter;
            }

        }

        public string SOAPActionUrl
        {
            get
            {
                try
                {
                    _SOAPActionUrl = ApplicationConfigurations.GetConfigurationValue(ConfigurationAppId, "SOAPActionUrl");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);

                }

                return _SOAPActionUrl;
            }

        }

        public string HttpWebRequestUrl
        {
            get
            {
                try
                {
                    _HttpWebRequestUrl = ApplicationConfigurations.GetConfigurationValue(ConfigurationAppId, "HttpWebRequestUrl");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);

                }

                return _HttpWebRequestUrl;
            }

        }

        public DataProvider()
        {

        }
        
        public IEnumerable<WorkItem> GetUnsentLockedMessagesRSInner()
        {
            var list = new List<WorkItem>();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand("dbo.Sp_GetUnsentLockedMessagesRSInner", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection.Open();
                    //command.Parameters.AddWithValue("@ProcessID", processId);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(PopulateEmailMessage(reader));
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
           
            return list;
        }

        public IEnumerable<WorkItem> GetUnsentMessagesRS()            
        {
            var list = new List<WorkItem>();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand("dbo.Sp_GetUnsentMessagesRS", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection.Open();
                    //command.Parameters.AddWithValue("@ProcessID", RowLockGUID);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(PopulateEmailMessage(reader));
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            
            return list;
        }


        public WorkItem PopulateRecord(SqlDataReader reader)
        {
            WorkItem item;
            try
            {
                var MessageID = reader.GetInt32(reader.GetOrdinal("MessageID"));

                item = new WorkItem(MessageID);

            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }

            return item;

        }

        public WorkItem PopulateEmailMessage(SqlDataReader reader)
        {
            WorkItem message;
            try
            {
                
                var MessageID = reader.GetFieldValueOrDefault<int>("MessageID");
                var Sender = reader.GetFieldValueOrDefault<string>("Sender");
                var Recipient = reader.GetFieldValueOrDefault<string>("Recipient");
                var CCRecipient = reader.GetFieldValueOrDefault<string>("CCRecipient") ?? Recipient;
                var BCCRecipient = reader.GetFieldValueOrDefault<string>("BCCRecipient") ?? Recipient;
                var Subject = reader.GetFieldValueOrDefault<string>("Subject");
                var Message = reader.GetFieldValueOrDefault<string>("Message");
                var Priority = reader.GetFieldValueOrDefault<int>("Priority");
                var QuotedPrintableMessage = reader.GetFieldValueOrDefault<bool>("QuotedPrintableMessage");
                //var HTMLFormatted = reader.GetFieldValueOrDefault<int>("HTMLFormatted");
               
                message = new WorkItem(MessageID, CCRecipient, BCCRecipient, Subject, QuotedPrintableMessage, Sender, Recipient, Message, Priority/*,  HTMLFormatted*/);

            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }

            return message;

        }

        public void MarkMessageAsSent(int messageId)
        {           
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand("dbo.Sp_MarkMessageAsSent", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection.Open();
                    command.Parameters.AddWithValue("@MessageID", messageId);
                    using (SqlDataReader reader = command.ExecuteReader()) { } ;
                    
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
                        
        }

    }
}
