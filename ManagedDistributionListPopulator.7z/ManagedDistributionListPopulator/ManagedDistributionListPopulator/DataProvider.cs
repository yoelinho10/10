﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using College.Configuration;


namespace ManagedDistributionListPopulator

{
    class DataProvider : IDataProvider  //where T : class
    {

        private const int ConfigurationAppId = 244; //ApplicationConfigurationId aunj por crear en el webapp

        private string _adsFilter;

        private string _connectionString;

        private SqlConnection _connection;

        public string connectionString
        {
            get
            {
                try
                {
                    _connectionString = ApplicationConfigurations.GetConfigurationValue(ConfigurationAppId, "ConnectionString");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);

                }

                return _connectionString;
            }

        }

        public string connectionStringMF
        {
            get
            {
                try
                {
                    _connectionString = ApplicationConfigurations.GetConfigurationValue(ConfigurationAppId, "ConnectionStringMF");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);

                }

                return _connectionString;
            }

        }

        public string AdsFilter
        {
            get
            {
                try
                {
                    _adsFilter = ApplicationConfigurations.GetConfigurationValue(ConfigurationAppId, "AdsFilter");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);

                }

                return _adsFilter;
            }

        }

        public DataProvider()
        {

        }

        public WorkItem PopulateRecord(SqlDataReader reader)
        {
            WorkItem workitem;
            try
            {
                var id = reader.GetInt32(reader.GetOrdinal("ListID"));
                var ListContainerADSPath = reader.GetString(reader.GetOrdinal("ListContainerADSPath"));
                var processed = false;

                workitem = new WorkItem(id, ListContainerADSPath, processed);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            return workitem;
        }
        public WorkItemfromCriteria PopulateRecordfromCriteria(SqlDataReader reader)
        {
            WorkItemfromCriteria workitem;
            try
            {
                var ListID = reader.GetInt32(reader.GetOrdinal("ListID"));
                var Processed = false;
                var AccountCode = reader.GetString(reader.GetOrdinal("AccountCode"));
                var CalendarCode = reader.GetString(reader.GetOrdinal("CalendarCode"));
                var CampusCode = reader.GetString(reader.GetOrdinal("CampusCode"));
                var FullAccountCode = reader.GetString(reader.GetOrdinal("FullAccountCode"));
                var PayGradeCode = reader.GetString(reader.GetOrdinal("PayGradeCode"));

                workitem = new WorkItemfromCriteria(ListID, Processed, AccountCode, CalendarCode, CampusCode, FullAccountCode, PayGradeCode);
            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }

            return workitem;
        }

        public WorkItemFromMember PopulateRecordfromMember(SqlDataReader reader)
        {
            WorkItemFromMember workitem;
            try
            {
                var MDID = reader.GetString(reader.GetOrdinal("MDID"));
                var ADSPath = reader.GetString(reader.GetOrdinal("ADsPath"));
                var processed = false;
                var PayGrade = reader.GetString(reader.GetOrdinal("PayGrade"));

                workitem = new WorkItemFromMember(ADSPath, processed, MDID, PayGrade);
            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }


            return workitem;
        }

        public IEnumerable<WorkItem> GetListTemplateRecords()
        {
            var list = new List<WorkItem>();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand("dbo.Sp_Get_ListTemplates", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(PopulateRecord(reader));
                        }
                    }
                }
            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }
            finally
            {


            }
            
            return list;

        }
        public WorkItemfromCriteria GetListCriteriaRecords(int list_id)
        {
            WorkItemfromCriteria res = new WorkItemfromCriteria();
            try
            {
                using (_connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand("dbo.Sp_Get_ListCriteria", _connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@ListID", list_id);
                    command.Connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            res = PopulateRecordfromCriteria(reader);
                        }
                    }
                }
            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }
            finally
            {

                _connection.Close();
            }
            return res;


        }
        public List<WorkItemFromMember> GetListMembersRecords(WorkItemfromCriteria item)
        {
            List<WorkItemFromMember> result = new List<WorkItemFromMember>();
            try
            {
                using (_connection = new SqlConnection(connectionStringMF))
                {
                    SqlCommand command = new SqlCommand("dbo.Sp_Get_ListFromMember", _connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CalendarCode", item.CalendarCode);
                    command.Parameters.AddWithValue("@AccountCode", item.AccountCode);
                    command.Parameters.AddWithValue("@CampusCode", item.CampusCode);
                    command.Parameters.AddWithValue("@OperatingUnit", item.FullAccountCode);
                    command.Parameters.AddWithValue("@PayGrade", item.PayGradeCodeCriteria);
                    command.Connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(PopulateRecordfromMember(reader));
                        }
                    }
                }
            }
            catch (Exception e)
            {

                throw new Exception(e.Message);
            }
            finally
            {

                _connection.Close();
            }
            return result;


        }

        
    }
}




