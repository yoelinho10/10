﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.DirectoryServices;
using College.Infrastructure.Applications.AppTracker;
using College;

namespace ManagedDistributionListPopulator
{
     class Job:IJob
    {

        protected readonly IDataProvider _provider;

        protected readonly ILogger _logger;       

        public Job(IDataProvider provider, ILogger logger)
        {
            _provider = provider;
            _logger = logger;
        }
        public Job( )
        {            
            
        }

        public void Execute()
        {

            try
            {
                _logger.logger(Logs.ApplicationLogEntryTypes.atInformation, "ManagedDistributionListPopulator Proccess Init");

                IEnumerable<WorkItem> TemplateRecordList = _provider.GetListTemplateRecords();

                UpdateDistributionList(TemplateRecordList);

                _logger.logger(Logs.ApplicationLogEntryTypes.atProcessSuccess, "ManagedDistributionListPopulator sucessfully completed");

            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure UpdateDistributionList(TemplateRecordList)");
                _logger.exception(ex);
                throw new Exception(ex.Message);
            }
        }

        private void UpdateDistributionList(IEnumerable<WorkItem> recordList)
        {
            try
            {
                foreach (var item in recordList)
                {
                    _logger.logger("Preparing to process" + item.ADSPath + " with a ListID of " + item.ListID + ".");
                    
                    UpdateDistributionList(item.ListID, item.ADSPath);

                    _logger.logger("Sucessfully update the membership for" + item.ADSPath + ".");
                    
                }

            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure UpdateDistributionList(item.ListID, item.ADSPath)");
                _logger.exception(ex);
                throw new Exception(ex.Message);
            }
                       
        }

        private void UpdateDistributionList(int listID, string listContainerADSPath)
        {
            DirectoryEntry objADAM;                   // Binding object.
            DirectoryEntry objgroupentry;                  // DirectoryEntry in Results.
            DirectorySearcher objSearchADAM;          // Search object.
            SearchResultCollection listobjSearchResults;  // Results collection.
            string strFilter = _provider.AdsFilter;                         // Filter to select objects.
            //string strFilter1 = "(&(objectCategory=user)(memberOf=CN=Distribution Groups,OU=mdc,DC=mdc.edu,DC=com))"; // Filter to select objects. another query...need to clarify cual...
            WorkItemfromCriteria WICriteriaRS;
            
            WICriteriaRS = GetAllfromCriteria(listID);
            _logger.logger("Sucessfully loaded list Id" + WICriteriaRS.ListID + "items from criteria");
           
            if (WICriteriaRS.ListID == 0)
            {
                return;
            }

            var ListMemberRS = GetListMembers(WICriteriaRS);
            _logger.logger("Sucessfully loaded " + ListMemberRS.Count() + "items from members table");

            //string workitemtemppath = "LDAP://MDCC.EDU/CN=Rodriguez, Jorge (Facilities Management),CN=Users,DC=mdcc,DC=edu";

            //MemberRS.ADSPath = workitemtemppath;
            //MemberRS.ListID = 33;

            try
            {
                objADAM = new DirectoryEntry(listContainerADSPath);
                objADAM.RefreshCache();                
            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure creqating the objADAM");
                _logger.exception(ex);
                throw new Exception(ex.Message);
            }

            try
            {
                objSearchADAM = new DirectorySearcher(objADAM); //Get the Distribution List Object
                objSearchADAM.Filter = strFilter;               //We are only instrested in Users
                objSearchADAM.SearchScope = SearchScope.Subtree;
                listobjSearchResults = objSearchADAM.FindAll();                
            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure Get the Distribution List Object");
                _logger.exception(ex);
                throw new Exception(ex.Message);
            }

            try
            {
                foreach (SearchResult objresult in listobjSearchResults)
                {
                    objgroupentry = objresult.GetDirectoryEntry();

                    foreach (object objmember in objgroupentry.Properties["member"])
                    {
                        if (!IsMemberInMembersRS(objmember, ListMemberRS))
                        {
                            objgroupentry.Properties["member"].Remove(objmember);
                            objgroupentry.CommitChanges();

                            _logger.audit("The following user was removed from " + listContainerADSPath + ":  " + objmember.ToString());
                            
                        }

                    }

                    foreach (var member in ListMemberRS)
                    {
                        if (!IsinMember(member, objgroupentry))
                        {
                            objgroupentry.Properties["member"].Add(member.ADSPath);
                            objgroupentry.CommitChanges();

                            _logger.audit("The following user was added from " + listContainerADSPath + ":  " + member.ADSPath);
                            
                        }

                    }

                }

            }
            
            catch (Exception ex)
            {
               _logger.logger("Generic exception failure adding or removing an object");
                _logger.exception(ex);
                throw new Exception(ex.Message);
            }            

        }

        private bool IsinMember(WorkItemFromMember MemberRS, DirectoryEntry objectgroupentry)
        {
            return objectgroupentry.Properties["member"].Contains(MemberRS.ADSPath);
        }

        private bool IsMemberInMembersRS(object objmember,IEnumerable<WorkItemFromMember> ListMemberRS)
        {
            var EscapedMemberADSPath = string.Empty;
            var FullMemberADSPath = "LDAP://MDCC.EDU/" + objmember.ToString();
            EscapedMemberADSPath = FullMemberADSPath.Replace("'", "''");
            try
            {                
                if (ListMemberRS.IsNullOrEmpty())
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                _logger.exception(e);
                throw new Exception(e.Message);
            }

            return ListMemberRS.Any(e => e.ADSPath == FullMemberADSPath);

        }

        private IEnumerable<WorkItemFromMember> GetListMembers(WorkItemfromCriteria WICriteriaRS)
        {
            IEnumerable<WorkItemFromMember> WIfromMembers;
            try
            {
                WIfromMembers = _provider.GetListMembersRecords(WICriteriaRS);
                                
            }
            catch (Exception e)
            {
                _logger.exception(e);
                throw new Exception(e.Message);
            }
                        
            return WIfromMembers;
        }

        private WorkItemfromCriteria GetAllfromCriteria(int listID)
        {
            WorkItemfromCriteria result;
            try
            {
                result = _provider.GetListCriteriaRecords(listID);

            }
            catch (Exception e)
            {
                _logger.exception(e);
                throw new Exception(e.Message);
            }

            return result;
        }

        

    }

    public class Logger : ILogger
    {
        private readonly string _ApplicationName = "ManagedDistributionListPopulator";

        private const int _TrackerAppId = 21; //AppTracker id differente del ApplicationConfigurationId

        private readonly int _ProcessId = Utilities.GenerateProcessID();

        public int TrackerAppId
        {
            get
            {
                return _TrackerAppId;
            }
        }
        public string ApplicationName
        {
            get
            {
                return _ApplicationName;
            }
        }

        public int ProcessId
        {
            get
            {
                return _ProcessId;
            }
        }

        public void logger(string description)
        {
            Logs.LogApplicationEvent(TrackerAppId, ProcessId, Logs.ApplicationLogEntryTypes.atInformation, 0, description);
        }

        public void logger(Logs.ApplicationLogEntryTypes stept, string description)
        {
            Logs.LogApplicationEvent(TrackerAppId, ProcessId, stept, 0, description);
        }

        public void audit(string description)
        {
            Audit.AuditApplicationEvent(TrackerAppId, ProcessId, Audit.AuditLogEntryTypes.atAuditInformation, ApplicationName, 0, description);
        }

        public void exception(Exception Ex)
        {
            College.ExceptionTools.HandleException(false, Ex);
        }
                
    }

}
