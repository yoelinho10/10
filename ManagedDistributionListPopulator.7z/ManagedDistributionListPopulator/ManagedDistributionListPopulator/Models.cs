﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ManagedDistributionListPopulator
{

    public class WorkItem { 
        public int ListID { get; set; }
        public string ADSPath { get; set; }
        public bool Processed { get; set; }

        public WorkItem(int list, string path, bool process)
        {
            ListID = list;
            ADSPath = path;
            Processed = process;
        }
        public WorkItem(int list, bool process)
        {
            ListID = list;            
            Processed = process;
        }
        public WorkItem( string path, bool process)
        {            
            ADSPath = path;
            Processed = process;
        }
        public WorkItem()
        {
          
        }

    }

    
    public class WorkItemfromCriteria: WorkItem
    {
       
        public string AccountCode { get; set; }
        public string CalendarCode { get; set; }
        public string CampusCode { get; set; }
        public string FullAccountCode { get; set; }
        private string PayGradeCode { get; set; }
        public string PayGradeCodeCriteria
        {
            get
            {
                return PayGradeCode.Replace(",", "','");                          
            }

        }


        public WorkItemfromCriteria(int listid,bool processed, string accountcode, string calendarcode, string campuscode, string fullaccountcode, string paygradecode) : base(listid,processed)
        {
            ListID = listid;           
            Processed = processed;
            AccountCode = accountcode;
            CalendarCode = calendarcode;
            CampusCode = campuscode;
            FullAccountCode = fullaccountcode;
            PayGradeCode = paygradecode;
                       
        }

        public WorkItemfromCriteria() 
        {
            
        }


        private string PayGradeCodeCriteriaF(string PayGradeCode)
        {
            return PayGradeCode.Replace(",", "','");
        }



    }

    public class WorkItemFromMember: WorkItem
    {
        public string MDID { get; set; }
        public string CalendarCode { get; set; }
        public string DepartmentID { get; set; }
        public string CampusCode { get; set; }        
        public string OperatingUnit { get; set; }
        public string PayGrade { get; set; }        
        public WorkItemFromMember(string path, bool processed, string mdid, string paygrade):base(path, processed)
        {
            ADSPath = path;
            Processed = processed;
            MDID = mdid;           
            PayGrade = paygrade;
        }

        public WorkItemFromMember() : base()
        {
          
        }

    }



    public static class Extensions
    {

        public static bool IsNullOrEmpty<T>(this IEnumerable<T> enumerable)
        {
            return enumerable == null || !enumerable.Any();
        }
              

    }


}