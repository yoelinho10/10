﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using College.Infrastructure.Applications.AppTracker;


namespace ManagedDistributionListPopulator
{
    class Program
    {
                
        static void Main(string[] args) 
        {
            IDataProvider pro = new DataProvider();
            ILogger logger = new Logger();
            Job job = new Job(pro,logger);

            try
            {            
                
                job.Execute();               
                
            }
            catch (Exception e)
            {
               
                throw new Exception(e.Message);
            }
            
        }
              
    }

}