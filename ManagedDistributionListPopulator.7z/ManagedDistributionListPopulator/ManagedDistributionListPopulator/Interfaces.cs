﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using College.Infrastructure.Applications.AppTracker;

namespace ManagedDistributionListPopulator
{
    interface IDataProvider
    {
        string AdsFilter{get;}
        List<WorkItemFromMember> GetListMembersRecords(WorkItemfromCriteria item);
        WorkItemfromCriteria GetListCriteriaRecords(int list_id);
        IEnumerable<WorkItem> GetListTemplateRecords();
        WorkItem PopulateRecord(SqlDataReader reader);
        WorkItemfromCriteria PopulateRecordfromCriteria(SqlDataReader reader);
        WorkItemFromMember PopulateRecordfromMember(SqlDataReader reader);

    }

    interface IJob
    {
        void Execute();
    }

    interface ILogger
    {
        int TrackerAppId { get; }
        string ApplicationName { get; }
        int ProcessId { get; }
        void logger(string description);
        void logger(Logs.ApplicationLogEntryTypes stept, string description);       
        void audit(string description);
        void exception(Exception Ex);

    }

}
