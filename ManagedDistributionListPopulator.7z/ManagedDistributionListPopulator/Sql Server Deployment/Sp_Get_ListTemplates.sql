USE [DistributionLists]
GO
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Diaz,,Yoel>
-- Create date: <01/25/2024,,>
-- Description:	<Get listId and path from Template table>
-- =============================================
CREATE PROCEDURE Sp_Get_ListTemplates
	-- Add the parameters for the stored procedure here
AS
BEGIN	
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	SELECT [ListID]
          ,[ListContainerADSPath]
	        
    FROM [DistributionLists].[dbo].[ListTemplates]
	
END
GO