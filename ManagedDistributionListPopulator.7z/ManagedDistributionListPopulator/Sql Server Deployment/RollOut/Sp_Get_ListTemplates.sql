USE [DistributionLists]
GO
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Diaz,,Yoel>
-- Create date: <01/25/2024,,>
-- Description:	<Get all the ,,>
-- =============================================
CREATE PROCEDURE Sp_Get_ListTemplates
	-- Add the parameters for the stored procedure here
AS
BEGIN	
	SET NOCOUNT ON;
    -- Insert statements for procedure here
	SELECT [ListID]
      ,[ListName]
      ,[ListContainerADSPath]
      ,[Owner]
      ,[WasListCreatedInAD]
      ,[ToBeDeleted]
    FROM [DistributionLists].[dbo].[ListTemplates]
	
END
GO
