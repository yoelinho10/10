USE [DistributionLists]
GO
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Diaz,,Yoel>
-- Create date: <01/25/2024,,>
-- Description:	<Get all the ,,>
-- =============================================
CREATE PROCEDURE Sp_Get_ListCriteria

	-- Add the parameters for the stored procedure here
	@ListID varchar(9)  
	
AS
BEGIN

	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT [ListCriteriaID]
      ,[ListID]
      ,[AccountCode]
      ,[CalendarCode]
      ,[CampusCode]
      ,[FullAccountCode]
      ,[PayGradeCode]
    FROM [DistributionLists].[dbo].[ListCriteria] C
	
	WHERE C.ListID = @ListID
	
END
GO
