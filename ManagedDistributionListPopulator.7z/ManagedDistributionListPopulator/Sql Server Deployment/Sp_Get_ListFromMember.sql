USE [Mainframe_data]
GO
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Diaz,,Yoel>
-- Create date: <01/25/2024>
-- Description:	<Get all the columns from matching table >
-- =============================================
CREATE PROCEDURE Sp_Get_ListFromMember

	-- Add the parameters for the stored procedure here
	@CalendarCode nvarchar(9),
	@AccountCode nvarchar(9),
	@CampusCode varchar(9),
	@OperatingUnit varchar(9),
	@PayGrade nvarchar(9)
	
AS

BEGIN

	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT [MDID]
      ,[CalendarCode]
      ,[DepartmentID]
      ,[CampusCode]
      ,[ADsPath]
      ,[OperatingUnit]
      ,[PayGrade]
  FROM [Mainframe_data].[dbo].[ActiveDirectoryEmployeeAccountsAndCampuses]
  
  WHERE  CalendarCode LIKE @CalendarCode AND DepartmentID = @AccountCode
									     AND CampusCode LIKE @CampusCode 
										 AND OperatingUnit LIKE @OperatingUnit
										 AND PayGrade in (@PayGrade)
	
END
GO