				
				
				SELECT
				l.[LogID] AS LogID,
                l.[ApplicationID] AS ApplicationID,
                l.[ProcessID] AS ProcessID,
                l.[TypeID] AS TypeID,
                l.[Date] AS Date,
                l.[Time] AS Time,
                l.[HostMachineName] AS HostMachineName,
                l.[MessageID] AS MessageID,
                l.[Message] AS Message,
                a.[ApplicationName] as ApplicationName,
                a.RunInterval as RunInterval,
                a.TimeOutInMinutes as TimeOutInMinutes,
                a.TrackerEnabled as TrackerEnabled,             
				CAST(CAST(l.[Date] AS DATE) AS DATETIME) + CAST(l.[Time] AS DATETIME) AS StartDateTime

				FROM [AppTracker].[dbo].[Log] l WITH (NOLOCK)
				INNER JOIN [AppTracker].[dbo].[Applications] a WITH (NOLOCK) ON l.ApplicationID = a.ApplicationID

				WHERE l.Date > DATEADD(day, -2, GETDATE())

				AND CAST(CAST(l.[Date] AS DATE) AS DATETIME) + CAST(l.[Time] AS DATETIME) >= DATEADD(HOUR, -9, DATEADD(DAY, 0, GETDATE()))
				
				AND l.TypeID IN (100, 30, 20, 110, 120)

				ORDER BY
				    l.Date ASC,
					l.Time asc;