-- Script para insertar valores en [AppTracker].[dbo].[Applications]
-- Asumiendo que ya ejecutaste el ALTER TABLE para agregar las columnas
-- RunIntervalValue, RunIntervalUnit, y RunDaysOfWeek.

USE [AppTracker];
GO

UPDATE [dbo].[Applications]
SET RunIntervalValue = 5, RunIntervalUnit = 'minute', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 1; -- Runs every 5 minutes 24 hours a day.

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'day', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 2; -- Every night at 3:30:00 AM (assuming daily)

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'day', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 3; -- Every night at 3:45:00 AM (assuming daily)

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'day', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 4; -- Every night at 3:00:00 AM (assuming daily)

UPDATE [dbo].[Applications]
SET RunIntervalValue = NULL, RunIntervalUnit = NULL, RunDaysOfWeek = NULL
WHERE ApplicationID = 5; -- NULL

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'day', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 6; -- Every night at 1:00:00 AM (assuming daily)

UPDATE [dbo].[Applications]
SET RunIntervalValue = NULL, RunIntervalUnit = NULL, RunDaysOfWeek = NULL
WHERE ApplicationID = 7; -- Runs multiple times per day (needs more specific interval)

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'minute', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID IN (8, 9, 25); -- Runs every 60 seconds 24 hours a day.

-- Assuming "every 8 hours from 6:00:00 AM for 11 hours" means 8-hour intervals within that time
UPDATE [dbo].[Applications]
SET RunIntervalValue = 8, RunIntervalUnit = 'hour', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 10;

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'day', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 11; -- Runs every morning at 8:30:00 AM. (assuming daily)

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'hour', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 12; -- Runs every hour 24 hours a day.

-- Assuming "four times a day" implies 6-hour intervals
UPDATE [dbo].[Applications]
SET RunIntervalValue = 6, RunIntervalUnit = 'hour', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 13;

-- Assuming "twice daily" implies 12-hour intervals
UPDATE [dbo].[Applications]
SET RunIntervalValue = 12, RunIntervalUnit = 'hour', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 14;

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'week', RunDaysOfWeek = 'MTWHFSU' -- Assuming weekly means every day of that week
WHERE ApplicationID = 15; -- Weekly

UPDATE [dbo].[Applications]
SET RunIntervalValue = 15, RunIntervalUnit = 'minute', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 16; -- Runs every 15 minutes 24 hours a day

UPDATE [dbo].[Applications]
SET RunIntervalValue = NULL, RunIntervalUnit = NULL, RunDaysOfWeek = NULL
WHERE ApplicationID IN (17, 18, 19, 20, 21, 22, 23, 24, 26, 32, 37, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 66, 67, 68, 69, 71, 81, 83, 85, 87, 93, 94, 95, 97, 98, 99, 100, 105, 106, 107, 114, 115, 116, 117, 118, 120, 121, 122, 123, 125, 128, 129, 132, 133, 137); -- NULL values

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'day', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 27; -- Runs every night a 3:00: AM (assuming daily)

-- TBA - To Be Announced, setting to NULL
UPDATE [dbo].[Applications]
SET RunIntervalValue = NULL, RunIntervalUnit = NULL, RunDaysOfWeek = NULL
WHERE ApplicationID IN (28, 29, 31, 33, 34, 35, 36, 75);

UPDATE [dbo].[Applications]
SET RunIntervalValue = 15, RunIntervalUnit = 'minute', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 30; -- Runs every 15 minutes 24 hours a day.

-- "Once every Summer" - Setting to NULL as it's not a regular interval
UPDATE [dbo].[Applications]
SET RunIntervalValue = NULL, RunIntervalUnit = NULL, RunDaysOfWeek = NULL
WHERE ApplicationID = 38;

-- Empty strings or unclear descriptions to NULL
UPDATE [dbo].[Applications]
SET RunIntervalValue = NULL, RunIntervalUnit = NULL, RunDaysOfWeek = NULL
WHERE ApplicationID IN (96, 119, 130, 134, 135, 136, 138, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151)
AND (RunInterval = '' OR RunInterval IS NULL OR RunInterval LIKE 'TBA' OR RunInterval LIKE 'TBD');

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'day', RunDaysOfWeek = 'MTWHF'
WHERE ApplicationID = 72; -- Runs from Monday through Friday at 3PM.

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'day', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 74; -- Runs daily

-- "Every hour from 8PM - 7AM" - Assuming it means every hour within that range daily
UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'hour', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 76;

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'hour', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 80; -- Every hour

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'day', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID IN (82, 86); -- Every day

UPDATE [dbo].[Applications]
SET RunIntervalValue = 1, RunIntervalUnit = 'day', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID IN (101, 103, 104, 108, 109, 110, 111, 127); -- Once a day

UPDATE [dbo].[Applications]
SET RunIntervalValue = 6, RunIntervalUnit = 'hour', RunDaysOfWeek = 'MTWHFSU'
WHERE ApplicationID = 151; -- Runs every 6 hours all days.

--SELECT * FROM [dbo].[Applications]; -- Optional: Verify the updates