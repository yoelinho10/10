--Update last run inserted for the AppTracker Job first run


UPDATE[AppTracker].[dbo].[Log] 
SET ApplicationID = 151
WHERE LogID = 755650189
    