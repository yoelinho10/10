
-- =============================================
-- Author:		<Diaz,,Yoel>
-- Create date: <01/25/2024,,>
-- Description:	<create columns [AppTracker].[dbo].[Applications]  table >
-- =============================================


ALTER TABLE [AppTracker].[dbo].[Applications]
ADD
    TimeOutInMinutes INT NOT NULL DEFAULT 180,
    TrackerEnabled BIT NOT NULL DEFAULT 1;

