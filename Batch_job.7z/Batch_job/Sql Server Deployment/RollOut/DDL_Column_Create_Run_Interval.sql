

ALTER TABLE [AppTracker].[dbo].[Applications]
ADD RunIntervalValue INT NULL,
    RunIntervalUnit VARCHAR(10) NULL,
    RunDaysOfWeek VARCHAR(7) NULL; -- Ej: MTWTFSU


--RunIntervalValue: An integer (INT) column that can store null values (NULL). This column will likely contain the number representing the interval (for example, 1 for one week, 3 for three days).

--RunIntervalUnit: A VARCHAR (variable-length character string) column with a maximum length of 10 characters, which can also store null values. This column will likely contain the unit of the interval (for example, 'week', 'days', 'hour', 'minute').

--RunDaysOfWeek: Another VARCHAR column with a maximum length of 7 characters, which can also store null values. The comment indicates that this column would be used to store the days of the week on which the process runs, using a one-character abbreviation per day (for example, 'MTWTFSU' for all days of the week).