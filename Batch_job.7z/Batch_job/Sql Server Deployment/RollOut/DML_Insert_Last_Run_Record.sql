

INSERT INTO [AppTracker].[dbo].[Log] (
    
    [ApplicationID],
    [ProcessID],
    [TypeID],
    [Date],
    [Time],
    [HostMachineName],
    [MessageID],
    [Message]
)
VALUES (
    
    138,
    888888888,
    100,
    '2025-04-23 00:00:00.000',
    '1900-01-01 00:00:00.000',
    'BATCH01',
    0,
    'Job Tracker Proccess Init'
);
