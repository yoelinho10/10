﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using College.Infrastructure.Applications.AppTracker;
using System.Data.SqlClient;

namespace Batch_job
{
    interface ILogger
    {
        int TrackerAppId { get; }
        string ApplicationName { get; }        
        int ProcessId { get; }
        void logger(string description);
        void logger(Logs.ApplicationLogEntryTypes stept, string description);
        void audit(string description);
        void exception(Exception Ex);

        

    }

    interface IJob
    {
        void Execute();
    }

    interface IDataProvider    
    {
        string Recipient { get; }
        IEnumerable<WorkItem> GetWorkItems(int optional = 0);
        SqlDataReader DataAccess(string parameter, string procedure);
        IEnumerable<WorkItem> GetWorkItemsProcessNotRunningJobs();
    }

}
