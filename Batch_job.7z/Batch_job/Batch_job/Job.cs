﻿using College.Infrastructure.Applications.AppTracker;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Web.Services.Description;

namespace Batch_job
{
    class Job : IJob
    {
        private IEnumerable<WorkItem> WorkItemsList;

        private IEnumerable<WorkItem> DelayedWorkItemsList;

        private List<WorkItem> StartList;

        private List<WorkItem> FatalErrorList;

        private List<WorkItem> NonFatalErrorList;

        private List<WorkItem> ProcessCompletedSuccessfullyList;

        private List<WorkItem> ProcessCompletedUnsuccessfullyList;

        private List<WorkItem> ProcessNotRunningJobsList;

        protected readonly IDataProvider _provider;

        protected readonly ILogger _logger;        

        private emailwebservice.Email _emailsender;
       
        public emailwebservice.Email emailsender
        {
            get
            {
                try
                {
                    _emailsender = new emailwebservice.Email(); 
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);

                }

                return _emailsender;
            }

        }
                
        public Job(IDataProvider provider, ILogger logger)
        {
            _provider = provider;
            _logger = logger;
        }
        public Job()
        {
        }

        public void Execute() 
        {
            try
            {
                _logger.logger(Logs.ApplicationLogEntryTypes.atProcessStarted, "Job Tracker Proccess Init");

                ProcessWorkItems();

                _logger.logger(Logs.ApplicationLogEntryTypes.atProcessSuccess, "Job Tracker Proccess sucessfully completed");
            }
            catch (Exception e)
            {
                _logger.logger("Job Tracker Proccess Failed"); 
                _logger.exception(e);

                throw new Exception(e.Message);
            }

        }

        private void ProcessWorkItems()
        {
            ProcessDelayedJobs();

            ProcessFailedJobs();

            ProcessNotRunningJobs();

            SendEmailMessage();

        }

        private void ProcessNotRunningJobs()
        {
            IEnumerable<WorkItem> list;
            try
            {
                list = _provider.GetWorkItemsProcessNotRunningJobs();
                var filteredItems = list.HasLastRunTime();
                ProcessNotRunningJobsList = new List<WorkItem>();
                foreach (WorkItem item in filteredItems)
                {
                    EvaluateLastRun(item);
                    
                }

            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure ProcessNotRunningJobs()");
                _logger.logger(ex.Message + ex.StackTrace);
                _logger.exception(ex);
                throw new Exception(ex.Message);
            }
            
        }

        private void EvaluateLastRun(WorkItem item)
        {
            try
            {
                string expresiondate = String.Empty;
                int passeddays = 0;
                
                switch (item.RunIntervalUnit)
                {
                    case "minute":
                        passeddays = DiasDesdeUltimoDiaPermitido(item.RunDaysOfWeek);
                        if (item.LastRunTime < DateTime.Now.AddHours(-24 * passeddays))
                        {
                            
                            ProcessNotRunningJobsList.Add(item);
                        }
                        break;

                    case "hour":
                        passeddays = DiasDesdeUltimoDiaPermitido(item.RunDaysOfWeek);
                        if (item.LastRunTime < DateTime.Now.AddHours(-24 * passeddays))
                        {
                            ProcessNotRunningJobsList.Add(item);
                        }
                        break;

                    case "day":
                        passeddays = DiasDesdeUltimoDiaPermitido(item.RunDaysOfWeek);
                        if (item.LastRunTime < DateTime.Now.AddDays(-item.RunIntervalValue * passeddays))
                        {
                            ProcessNotRunningJobsList.Add(item);
                        }
                        break;

                    case "week":
                        if (item.LastRunTime < DateTime.Now.AddDays(-7))
                        {
                            ProcessNotRunningJobsList.Add(item);
                        }
                        break;

                    default:
                        passeddays = DiasDesdeUltimoDiaPermitido(item.RunDaysOfWeek);
                        if (item.LastRunTime < DateTime.Now.AddHours(-24 * passeddays))
                        {

                            ProcessNotRunningJobsList.Add(item);
                        }
                        
                        break;
                }
            }           

            catch (Exception ex)
            {
                _logger.logger("Generic exception failure EvaluateLastRun()");
                _logger.logger(ex.Message + ex.StackTrace);
                _logger.exception(ex);
            }

        }
        private int DiasDesdeUltimoDiaPermitido(string runDaysOfWeek)
        {
            // Mapeo de letras a números de día (Sunday=0, Monday=1, ..., Saturday=6)
            var dayMap = new Dictionary<char, int>
            {
                { 'U', 0 }, // Sunday
                { 'M', 1 }, // Monday
                { 'T', 2 }, // Tuesday
                { 'W', 3 }, // Wednesday
                { 'H', 4 }, // Thursday
                { 'F', 5 }, // Friday
                { 'S', 6 }  // Saturday
            };

            int today = (int)DateTime.Today.DayOfWeek;

            // Convertimos los días habilitados a int
            var allowedDays = runDaysOfWeek
                .Where(c => dayMap.ContainsKey(c))
                .Select(c => dayMap[c])
                .ToList();

            // Calculamos distancia desde hoy hacia atrás
            for (int i = 1; i <= 7; i++)
            {
                int checkDay = (today - i + 7) % 7;
                if (allowedDays.Contains(checkDay))
                    return i;
            }

            return 1; // En caso raro de que no haya coincidencias
        }


        private void ProcessDelayedJobs()
        {

            DelayedWorkItemsList = new List<WorkItem>();
            var DelayedWorkItemsListv = GetWorkItems(1);
                       
            var StartListv = DelayedWorkItemsListv.Where(x => x.TypeID == 100).ToList();
            var FatalErrorListv = DelayedWorkItemsListv.Where(x => x.TypeID == 30).ToList();
            
            var ProcessCompletedSuccessfullyListv = DelayedWorkItemsListv.Where(x => x.TypeID == 110).ToList();
            var ProcessCompletedUnsuccessfullyListv = DelayedWorkItemsListv.Where(x => x.TypeID == 120).ToList();


            var filteredWorkItems  = StartListv.Where(startItem =>!FatalErrorListv.Any(errorItem =>startItem.ApplicationID == errorItem.ApplicationID 
                                                    &&startItem.ProcessID == errorItem.ProcessID) 
                                                    && !ProcessCompletedSuccessfullyListv.Any(successItem =>startItem.ApplicationID == successItem.ApplicationID 
                                                    && startItem.ProcessID == successItem.ProcessID) 
                                                    && !ProcessCompletedUnsuccessfullyListv.Any(unsuccessfulItem => startItem.ApplicationID == unsuccessfulItem.ApplicationID 
                                                    && startItem.ProcessID == unsuccessfulItem.ProcessID)
            )
            .ToList();                      

             DelayedWorkItemsList = filteredWorkItems.Where(item => item.StartDateTime < DateTime.Now.AddMinutes(-item.TimeOutInMinutes));

        }

        private void ProcessFailedJobs()
        {
            WorkItemsList = new List<WorkItem>();
            StartList = new List<WorkItem>();
            FatalErrorList = new List<WorkItem>();
            NonFatalErrorList = new List<WorkItem>();
            ProcessCompletedSuccessfullyList = new List<WorkItem>();
            ProcessCompletedUnsuccessfullyList = new List<WorkItem>();

            WorkItemsList = GetWorkItems();
            StartList = WorkItemsList.Where(x => x.TypeID == 100).ToList();
            FatalErrorList = WorkItemsList.Where(x => x.TypeID == 30).ToList();
            NonFatalErrorList = WorkItemsList.Where(x => x.TypeID == 20).ToList();
            ProcessCompletedSuccessfullyList = WorkItemsList.Where(x => x.TypeID == 110).ToList();
            ProcessCompletedUnsuccessfullyList = WorkItemsList.Where(x => x.TypeID == 120).ToList();
            
        }

        public IEnumerable<WorkItem> GetWorkItems(int optional = 0)
        {
            IEnumerable<WorkItem> list;
            try
            {
                list = _provider.GetWorkItems(optional);

            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure GetWorkItems()");
                _logger.logger(ex.Message + ex.StackTrace);
                _logger.exception(ex);
                throw new Exception(ex.Message);
            }
            return list;

        }

        private void SendEmailMessage()
        {

            SendEmailMessageDelayed();
            SendEmailMessageFatalError();
            SendEmailMessageNonFatalError();
            SendEmailProcessCompletedUnsuccessfully();
            SendEmailProcessNotRunningJobs();

        }

        private void SendEmailProcessNotRunningJobs()
        {
            if (!ProcessNotRunningJobsList.Any())
            {
                return;
            }
            var recipient = _provider.Recipient;
            var myList = new List<string> { recipient };
            string[] arrayRecipient = myList.ToArray();
            string subject = "TrackerLogbatchAlert Process Not Running Jobs List";

            StringBuilder messageBuilder = new StringBuilder();
            messageBuilder.AppendLine("<html><body style='font-family: Arial, sans-serif;'>");
            messageBuilder.AppendLine("<h3 style='text-align: center;'>Process Not Running Jobs List in Tracker Log Batch Alert</h3>");
            messageBuilder.AppendLine("<table border='1' cellspacing='0' cellpadding='5' style='width: 100%; border-collapse: collapse;'>");
            messageBuilder.AppendLine("<tr style='background-color: #f2f2f2;'>");
            messageBuilder.AppendLine("<th style='text-align: center;'>Application ID</th>");
            messageBuilder.AppendLine("<th style='text-align: center;'>Application Name</th>");
            messageBuilder.AppendLine("<th style='text-align: center;'>Last Run Time</th>");
            messageBuilder.AppendLine("<th style='text-align: center;'>RunIntervalValue</th>");
            messageBuilder.AppendLine("<th style='text-align: center;'>RunIntervalUnit</th>");
            messageBuilder.AppendLine("</tr>");

            try
            {
                foreach (WorkItem workItem in ProcessNotRunningJobsList)
                {
                    messageBuilder.AppendLine("<tr>");
                    messageBuilder.AppendLine($"<td style='text-align: center;'>&nbsp &nbsp &nbsp{workItem.ApplicationID}</td>");
                    messageBuilder.AppendLine($"<td style='text-align: center;'>{workItem.AplicationName}</td>");
                    messageBuilder.AppendLine($"<td style='text-align: center;'>{workItem.LastRunTime:yyyy-MM-dd HH:mm:ss}</td>");
                    messageBuilder.AppendLine($"<td style='text-align: right;'>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp{workItem.RunIntervalValue}</td>");
                    messageBuilder.AppendLine($"<td style='text-align: right;'>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp{workItem.RunIntervalUnit}</td>");
                    messageBuilder.AppendLine("</tr>");
                }

                messageBuilder.AppendLine("</table>");
                messageBuilder.AppendLine("</body></html>");

                string message = messageBuilder.ToString();

                if (arrayRecipient.Any() && !string.IsNullOrWhiteSpace(message) && !string.IsNullOrWhiteSpace(subject))
                {
                    emailsender.SendEmail(arrayRecipient, message, subject); // Asegúrate de que el email se envíe como HTML
                }
            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure SendEmailProcessNotRunningJobs()" + ex.Message);
                _logger.exception(ex);
            }
        }


        private void SendEmailMessageFatalError()
        {   

            if (!FatalErrorList.Any())
            {
                return;
            }

            var recipient = _provider.Recipient;
            var myList = new List<string> { recipient };
            string[] arrayRecipient = myList.ToArray();
            string subject = "TrackerLogbatchAlert Fatal Error";

            StringBuilder messageBuilder = new StringBuilder();
            messageBuilder.AppendLine("<html><body>");
            messageBuilder.AppendLine("<h3>Fatal Errors in Tracker Log Batch Alert</h3>");
            messageBuilder.AppendLine("<table border='1' cellspacing='0' cellpadding='5'>");
            messageBuilder.AppendLine("<tr><th>Application ID</th><th>Application Name</th><th>Date</th><th>Time</th><th>Type ID</th><th>Message</th></tr>");

            try
            {
                foreach (WorkItem workItem in FatalErrorList)
                {
                    messageBuilder.AppendLine("<tr>");
                    messageBuilder.AppendLine($"<td>{workItem.ApplicationID}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.AplicationName}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.Date:yyyy-MM-dd}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.Time.TimeOfDay}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.TypeID}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.Message}</td>");
                    messageBuilder.AppendLine("</tr>");
                }

                messageBuilder.AppendLine("</table>");
                messageBuilder.AppendLine("</body></html>");

                string message = messageBuilder.ToString();

                if (arrayRecipient.Any() && !string.IsNullOrWhiteSpace(message) && !string.IsNullOrWhiteSpace(subject))
                {
                    emailsender.SendEmail(arrayRecipient, message, subject); // Asegúrate de que el email se envíe como HTML
                }
            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure SendEmailMessageFatalError()" + ex.Message);
                _logger.exception(ex);
            }
        }
        private void SendEmailProcessCompletedUnsuccessfully()
        {
            if (!ProcessCompletedUnsuccessfullyList.Any())
            {
                return;
            }
            var recipient = _provider.Recipient;
            var myList = new List<string> { recipient };
            string[] arrayRecipient = myList.ToArray();
            string subject = "TrackerLogbatchAlert Completed Unsuccessfully";

            StringBuilder messageBuilder = new StringBuilder();
            messageBuilder.AppendLine("<html><body>");
            messageBuilder.AppendLine("<h3>Completed Unsuccessfully in Tracker Log Batch Alert</h3>");
            messageBuilder.AppendLine("<table border='1' cellspacing='0' cellpadding='5'>");
            messageBuilder.AppendLine("<tr><th>Application ID</th><th>Application Name</th><th>Date</th><th>Time</th><th>Type ID</th><th>Message</th></tr>");

            try
            {
                foreach (WorkItem workItem in ProcessCompletedUnsuccessfullyList)
                {
                    messageBuilder.AppendLine("<tr>");
                    messageBuilder.AppendLine($"<td>{workItem.ApplicationID}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.AplicationName}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.Date:yyyy-MM-dd}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.Time.TimeOfDay}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.TypeID}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.Message}</td>");
                    messageBuilder.AppendLine("</tr>");
                }

                messageBuilder.AppendLine("</table>");
                messageBuilder.AppendLine("</body></html>");

                string message = messageBuilder.ToString();

                if (arrayRecipient.Any() && !string.IsNullOrWhiteSpace(message) && !string.IsNullOrWhiteSpace(subject))
                {
                    emailsender.SendEmail(arrayRecipient, message, subject); // Asegúrate de que el email se envíe como HTML
                }
            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure SendEmailProcessCompletedUnsuccessfully()" + ex.Message);
                _logger.exception(ex);
            }
        }

        
        private void SendEmailMessageNonFatalError()
        {
            if (!NonFatalErrorList.Any())
            {
                return;
            }
            var recipient = _provider.Recipient;
            var myList = new List<string> { recipient };
            string[] arrayRecipient = myList.ToArray();
            string subject = "TrackerLogbatchAlert Non Fatal Error";

            StringBuilder messageBuilder = new StringBuilder();
            messageBuilder.AppendLine("<html><body>");
            messageBuilder.AppendLine("<h3>Non Fatal Error in Tracker Log Batch Alert</h3>");
            messageBuilder.AppendLine("<table border='1' cellspacing='0' cellpadding='5'>");
            messageBuilder.AppendLine("<tr><th>Application ID</th><th>Application Name</th><th>Date</th><th>Time</th><th>Type ID</th><th>Message</th></tr>");

            try
            {
                foreach (WorkItem workItem in NonFatalErrorList)
                {
                    messageBuilder.AppendLine("<tr>");
                    messageBuilder.AppendLine($"<td>{workItem.ApplicationID}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.AplicationName}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.Date:yyyy-MM-dd}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.Time.TimeOfDay}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.TypeID}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.Message}</td>");
                    messageBuilder.AppendLine("</tr>");
                }

                messageBuilder.AppendLine("</table>");
                messageBuilder.AppendLine("</body></html>");

                string message = messageBuilder.ToString();

                if (arrayRecipient.Any() && !string.IsNullOrWhiteSpace(message) && !string.IsNullOrWhiteSpace(subject))
                {
                    emailsender.SendEmail(arrayRecipient, message, subject); // Asegúrate de que el email se envíe como HTML
                }
            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure SendEmailMessageNonFatalError()" + ex.Message);
                _logger.exception(ex);
            }
        }

        
        private void SendEmailMessageDelayed()
        {
            if (!DelayedWorkItemsList.Any())
            {
                return;
            }
            var recipient = _provider.Recipient;
            var myList = new List<string> { recipient };
            string[] arrayRecipient = myList.ToArray();
            string subject = "TrackerLogbatchAlert Delayed or unfinished Jobs Alert";

            StringBuilder messageBuilder = new StringBuilder();
            messageBuilder.AppendLine("<html><body>");
            messageBuilder.AppendLine("<h3>Delayed or unfinished Log Batch Alert</h3>");
            messageBuilder.AppendLine("<table border='1' cellspacing='0' cellpadding='5'>");
            messageBuilder.AppendLine("<tr><th>Application ID</th><th>Application Name</th><th>Date</th><th>Time</th><th>Type ID</th><th>Message</th></tr>");

            try
            {
                foreach (WorkItem workItem in DelayedWorkItemsList)
                {
                    messageBuilder.AppendLine("<tr>");
                    messageBuilder.AppendLine($"<td>{workItem.ApplicationID}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.AplicationName}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.Date:yyyy-MM-dd}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.Time.TimeOfDay}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.TypeID}</td>");
                    messageBuilder.AppendLine($"<td>{workItem.Message}</td>");
                    messageBuilder.AppendLine("</tr>");
                }

                messageBuilder.AppendLine("</table>");
                messageBuilder.AppendLine("</body></html>");

                string message = messageBuilder.ToString();

                if (arrayRecipient.Any() && !string.IsNullOrWhiteSpace(message) && !string.IsNullOrWhiteSpace(subject))
                {
                    emailsender.SendEmail(arrayRecipient, message, subject); // Asegúrate de que el email se envíe como HTML
                }
            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure SendEmailMessageDelayed()" + ex.Message);
                _logger.exception(ex);
            }
        }

    }


}
