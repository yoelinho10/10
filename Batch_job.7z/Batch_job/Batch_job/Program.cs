﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Batch_job
{
    class Program
    {
        static void Main(string[] args)
        {
            ILogger logger = new Logger();
            IDataProvider pro = new DataProvider(logger);            
            //Job job = new Job(pro, logger);
            IJob job = new Job(pro, logger);
            try
            {
                job.Execute();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }

        }
    }
}
