﻿using College.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Security.Policy;

namespace Batch_job
{
    class DataProvider : IDataProvider
    {

        protected ILogger _logger;

        protected SqlConnection con;

        private string _configurationAppId = ConfigurationManager.AppSettings["AppId"];

        public int configurationAppId
        {
            get
            {
                return int.Parse(_configurationAppId);
            }

        }

        private string _connectionString;

        public string connectionString
        {
            get
            {
                try
                {
                    _connectionString = ApplicationConfigurations.GetConfigurationValue(configurationAppId, "ConnectionString");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);

                }

                return _connectionString;
            }
        }
        private string _recipient;
        public string Recipient
        {
            get
            {
                try
                {
                    _recipient = ApplicationConfigurations.GetConfigurationValue(configurationAppId, "RECIPIENT-EMAIL");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);

                }

                return _recipient;
            }

        }

        public DataProvider()
        {

        }
        public DataProvider(ILogger logger)
        {
            _logger = logger;
        }
        public SqlDataReader DataAccess(string connectionString, string procedure)
        {
            SqlDataReader reader;
            con = new SqlConnection(connectionString);
            try
            {
                con.Open();
                reader = College.Data.SqlClient.SQLTools.ExecuteReaderStoredProcedure(procedure, con);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return reader;

        }

        public SqlDataReader DataAccess(string procedure, string constr, SqlParameter[] parameters)
        {

            con = new SqlConnection(constr);
            SqlDataReader reader;
            try
            {
                con.Open();
                reader = College.Data.SqlClient.SQLTools.ExecuteReaderStoredProcedure(procedure, con, parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return reader;
        }

        public IEnumerable<WorkItem> GetWorkItems(int optional = 0)
        {
            var list = new List<WorkItem>();
            SqlDataReader reader = null;
            try
            { 
                if (optional == 1)
                {
                    try
                    {
                        SqlParameter[] dbparameters = new SqlParameter[]
                        {
                            new SqlParameter("@UseAlternativeQuery",optional),
                        };

                        reader = DataAccess("dbo.Get_AppTracker_Population", connectionString, dbparameters);
                        while (reader.Read())
                        {

                            try
                            {
                                list.Add(PopulateWorkItems(reader));
                            }
                            catch (Exception ex)
                            {

                                _logger.logger("Exception:" + ex.Message + "Stacktrace:" + ex.StackTrace);
                            }

                        }


                    }
                    catch (Exception e)
                    {
                        throw new Exception(e.Message);
                    }
                    finally
                    {

                        con.Close();
                    }

                }
                else
                {
                    //_logger.logger("logger before readcer declared");
                    reader = DataAccess(connectionString, "dbo.Get_AppTracker_Population");
                    //_logger.logger("logger after readcer declared");

                    while (reader.Read())
                    {

                        try
                        {
                            list.Add(PopulateWorkItems(reader));
                        }
                        catch (Exception ex)
                        {

                            _logger.logger("Exception:" + ex.Message + "Stacktrace:" + ex.StackTrace);
                        }

                    }
                }               

            }
            catch (Exception e)
            {
                _logger.logger(e.Message);
                _logger.logger(e.StackTrace);
                throw new Exception(e.Message);
            }
            finally
            {
                reader.Close();
                con.Close();
            }


            return list;
        }

        private WorkItem PopulateWorkItems(SqlDataReader reader)
        {
            WorkItem WORKITEM = new WorkItem();
            int LogID = 0;
            int ApplicationID = 0;

            try
            {
                    LogID = reader.GetFieldValueOrDefault<int>("LogID");
                    ApplicationID = reader.GetFieldValueOrDefault<int>("ApplicationID");
                var ProcessID = reader.GetFieldValueOrDefault<int>("ProcessID");
                var TypeID = reader.GetFieldValueOrDefault<int>("TypeID");
                var Date = reader.GetFieldValueOrDefault<DateTime>("Date");
                var Time = reader.GetFieldValueOrDefault<DateTime>("Time");
                var HostMachineName = reader.GetFieldValueOrDefault<string>("HostMachineName");
                var MessageID = reader.GetFieldValueOrDefault<int>("MessageID");
                var Message = reader.GetFieldValueOrDefault<string>("Message");
                var AplicationName = reader.GetFieldValueOrDefault<string>("ApplicationName");
                var TimeOutInMinutes = reader.GetFieldValueOrDefault<int>("TimeOutInMinutes");
                var TrackerEnabled = reader.GetFieldValueOrDefault<bool>("TrackerEnabled");
                var StartDateTime = reader.GetFieldValueOrDefault<DateTime>("StartDateTime");
                WORKITEM = new WorkItem(LogID, ApplicationID, ProcessID, TypeID, Date, Time, HostMachineName, MessageID, Message, AplicationName, TimeOutInMinutes, TrackerEnabled, StartDateTime);

            }
            catch (Exception e)
            { 
                _logger.logger("Exception failure in PopulateWorkItems()" + "Log id " + LogID + "Studentid" + ApplicationID + "exception message:" + e.Message);
                _logger.logger(e.Message);
                //throw new Exception(e.Message);

            }
            return WORKITEM;
        }
    }
}
