﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using College.Infrastructure.Applications.AppTracker;
using College;
using College.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Configuration;
using College.DirectoryServices;

namespace Batch_job
{   
        public class WorkItem
        {
        public int LogID { get; set; }
        public int ApplicationID { get; set; }
        public int ProcessID { get; set; }
        public int TypeID { get; set; }
        public DateTime Date { get; set; }
        public DateTime Time { get; set; }
        public string HostMachineName { get; set; }
        public int MessageID { get; set; }
        public string Message { get; set; }
        public string AplicationName { get; set; }
        public int TimeOutInMinutes { get; set; }
        public bool TrackerEnabled  { get; set; }
        public DateTime StartDateTime { get; set; }

        public WorkItem(int logID, int applicationID, int processID, int typeID, DateTime date, DateTime time, string hostMachineName, int messageID, string message, string aplicationName, int timeOutInMinutes, bool trackerEnabled, DateTime startDateTime)
        {
            LogID = logID;
            ApplicationID = applicationID;
            ProcessID = processID;
            TypeID = typeID;
            Date = date;
            Time = time;
            HostMachineName = hostMachineName;
            MessageID = messageID;
            Message = message;
            AplicationName = aplicationName;
            TimeOutInMinutes = timeOutInMinutes;
            TrackerEnabled = trackerEnabled;
            StartDateTime = startDateTime;
        }

            public WorkItem()
            {
                
            }
            
        }

        public static class Extensions
        {

            public static bool IsNullOrEmpty<T>(this IEnumerable<T> enumerable)
            {
                return enumerable == null || !enumerable.Any();
            }


            public static T GetFieldValueOrDefault<T>(this SqlDataReader reader, string name)
            {
                int index = reader.GetOrdinal(name);
                T value = reader.IsDBNull(index) ? default(T) : reader.GetFieldValue<T>(index);
                return value;
            }

        public static IEnumerable<T> AssignEach<T>(this IEnumerable<T> source, Action<T> assignAction)
        {
            foreach (var item in source)
            {
                assignAction(item);
                yield return item;
            }
        }



        }

        public class Logger : ILogger
        {
            private readonly string _ApplicationName = "Destiny One Enrollment Event";

            private readonly int _TrackerAppId = int.Parse(ConfigurationManager.AppSettings["TrackerAppId"]); //AppTracker id differente del ApplicationConfigurationId

            private readonly int _ProcessId = College.Infrastructure.Applications.AppTracker.Utilities.GenerateProcessID();

            public int TrackerAppId
            {
                get
                {
                    return _TrackerAppId;
                }
            }
            public string ApplicationName
            {
                get
                {
                    return _ApplicationName;
                }
            }

            public int ProcessId
            {
                get
                {
                    return _ProcessId;
                }
            }

            public void logger(string description)
            {
                Logs.LogApplicationEvent(TrackerAppId, ProcessId, Logs.ApplicationLogEntryTypes.atInformation, 0, description);
            }

            public void logger(Logs.ApplicationLogEntryTypes stept, string description)
            {
                Logs.LogApplicationEvent(TrackerAppId, ProcessId, stept, 0, description);
            }

            public void audit(string description)
            {
                Audit.AuditApplicationEvent(TrackerAppId, ProcessId, Audit.AuditLogEntryTypes.atAuditInformation, ApplicationName, 0, description);
            }

            public void exception(Exception Ex)
            {
                College.ExceptionTools.HandleException(false, Ex);
            }

        }

        


}
