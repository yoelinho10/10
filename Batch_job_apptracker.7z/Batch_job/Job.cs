﻿using College.Infrastructure.Applications.AppTracker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web.Services.Description;

namespace Batch_job
{
    class Job : IJob
    {
        private IEnumerable<WorkItem> WorkItemsList;

        private IEnumerable<WorkItem> DelayedWorkItemsList;

        private List<WorkItem> StartList;

        private List<WorkItem> FatalErrorList;

        private List<WorkItem> NonFatalErrorList;

        private List<WorkItem> ProcessCompletedSuccessfullyList;

        private List<WorkItem> ProcessCompletedUnsuccessfullyList;

        protected readonly IDataProvider _provider;

        protected readonly ILogger _logger;        

        private emailwebservice.Email _emailsender;
       
        public emailwebservice.Email emailsender
        {
            get
            {
                try
                {
                    _emailsender = new emailwebservice.Email(); 
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);

                }

                return _emailsender;
            }

        }
                
        public Job(IDataProvider provider, ILogger logger)
        {
            _provider = provider;
            _logger = logger;
        }
        public Job()
        {
        }

        public void Execute() 
        {
            try
            {
                _logger.logger(Logs.ApplicationLogEntryTypes.atProcessStarted, "Job Tracker Proccess Init");

                ProcessWorkItems();

                _logger.logger(Logs.ApplicationLogEntryTypes.atProcessSuccess, "Job Tracker Proccess sucessfully completed");
            }
            catch (Exception e)
            {
                _logger.logger("Job Tracker Proccess Failed"); 
                _logger.exception(e);

                throw new Exception(e.Message);
            }

        }

        private void ProcessWorkItems()
        {
            ProcessDelayedJobs();

            ProcessFailedJobs();

            SendEmailMessage();

        }

        private void ProcessDelayedJobs()
        {

            DelayedWorkItemsList = new List<WorkItem>();
            var DelayedWorkItemsListv = GetWorkItems(1);
                       
            var StartListv = DelayedWorkItemsListv.Where(x => x.TypeID == 100).ToList();
            var FatalErrorListv = DelayedWorkItemsListv.Where(x => x.TypeID == 30).ToList();
            
            var ProcessCompletedSuccessfullyListv = DelayedWorkItemsListv.Where(x => x.TypeID == 110).ToList();
            var ProcessCompletedUnsuccessfullyListv = DelayedWorkItemsListv.Where(x => x.TypeID == 120).ToList();


            var filteredWorkItems  = StartListv.Where(startItem =>!FatalErrorListv.Any(errorItem =>startItem.ApplicationID == errorItem.ApplicationID 
                                                    &&startItem.ProcessID == errorItem.ProcessID) 
                                                    && !ProcessCompletedSuccessfullyListv.Any(successItem =>startItem.ApplicationID == successItem.ApplicationID 
                                                    && startItem.ProcessID == successItem.ProcessID) 
                                                    && !ProcessCompletedUnsuccessfullyListv.Any(unsuccessfulItem => startItem.ApplicationID == unsuccessfulItem.ApplicationID 
                                                    && startItem.ProcessID == unsuccessfulItem.ProcessID)
            )
            .ToList();
                      

             DelayedWorkItemsList = filteredWorkItems.Where(item => item.StartDateTime < DateTime.Now.AddMinutes(-item.TimeOutInMinutes));

        }

        private void ProcessFailedJobs()
        {
            WorkItemsList = new List<WorkItem>();
            StartList = new List<WorkItem>();
            FatalErrorList = new List<WorkItem>();
            NonFatalErrorList = new List<WorkItem>();
            ProcessCompletedSuccessfullyList = new List<WorkItem>();
            ProcessCompletedUnsuccessfullyList = new List<WorkItem>();

            WorkItemsList = GetWorkItems();
            StartList = WorkItemsList.Where(x => x.TypeID == 100).ToList();
            FatalErrorList = WorkItemsList.Where(x => x.TypeID == 30).ToList();
            NonFatalErrorList = WorkItemsList.Where(x => x.TypeID == 20).ToList();
            ProcessCompletedSuccessfullyList = WorkItemsList.Where(x => x.TypeID == 110).ToList();
            ProcessCompletedUnsuccessfullyList = WorkItemsList.Where(x => x.TypeID == 120).ToList();
            
        }

        public IEnumerable<WorkItem> GetWorkItems(int optional = 0)
        {
            IEnumerable<WorkItem> list;
            try
            {
                list = _provider.GetWorkItems(1);

            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure GetWorkItems()");
                _logger.logger(ex.Message + ex.StackTrace);
                _logger.exception(ex);
                throw new Exception(ex.Message);
            }
            return list;

        }

        private void SendEmailMessage()
        {

            SendEmailMessageDelayed();
            SendEmailMessageFatalError();
            SendEmailMessageNonFatalError();
            SendEmailProcessCompletedUnsuccessfully();
            
        }

        private void SendEmailMessageFatalError()
        {
            var recipient = _provider.Recipient;
            var myList = new List<string>();
            myList.Add(recipient);
            string[] arrayrecipient = myList.ToArray();
            string subject = "TrackerLogbatchReport Fatal Error";
            StringBuilder messageBuilder = new StringBuilder();
            
            try
            {
                foreach (WorkItem workItem in FatalErrorList)
                {
                    messageBuilder.AppendLine($"Application ID: {workItem.ApplicationID} Application Name: {workItem.AplicationName} Date: {workItem.Date.ToString("yyyy-MM-dd")} Time: {workItem.Time.TimeOfDay} Job tracker TypeID: {workItem.TypeID} Fatal Error Application Message: {workItem.Message}").Append(Environment.NewLine);
                    //message += "Application ID: "+ workItem.ApplicationID + " Aplication Name: " + workItem.AplicationName + " Date: " + workItem.Date.ToString("yyyy-MM-dd") + " Time: " + workItem.Time.TimeOfDay + " Job tracker TypeID: " + workItem.TypeID + " Fatal Error Application Message: " + workItem.Message + "\n"; ;

                }
                string message = messageBuilder.ToString();
                if (arrayrecipient != null && arrayrecipient.Any() && !string.IsNullOrWhiteSpace(message) && !string.IsNullOrWhiteSpace(subject))
                {
                    emailsender.SendEmail(arrayrecipient, message, subject);

                }               

            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure SendEmailMessageFatalError()" + ex.Message);
                _logger.exception(ex);
                throw new Exception(ex.Message);
            }
        }
        private void SendEmailMessageNonFatalError()
        {
            var recipient = _provider.Recipient;
            var myList = new List<string>();
            myList.Add(recipient);
            string[] arrayrecipient = myList.ToArray();
            string subject = "TrackerLogbatchReport Non Fatal Error";
           
            StringBuilder messageBuilder = new StringBuilder();
            try
            {
                foreach (WorkItem workItem in NonFatalErrorList)
                {
                    messageBuilder.AppendLine($"Application ID: {workItem.ApplicationID} Application Name: {workItem.AplicationName} Date: {workItem.Date.ToString("yyyy-MM-dd")} Time: {workItem.Time.TimeOfDay} Job tracker TypeID: {workItem.TypeID} Fatal Error Application Message: {workItem.Message}").Append(Environment.NewLine);
                    //message += "Application ID: " + workItem.ApplicationID + " Aplication Name: " + workItem.AplicationName + " Date: " + workItem.Date.ToString("yyyy-MM-dd") + " Time: " + workItem.Time.TimeOfDay + " Job tracker TypeID: " + workItem.TypeID + " Fatal Error Application Message: " + workItem.Message + "\n"; ;

                }
                string message = messageBuilder.ToString();
                if (arrayrecipient != null && arrayrecipient.Any() && !string.IsNullOrWhiteSpace(message) && !string.IsNullOrWhiteSpace(subject))
                {
                    emailsender.SendEmail(arrayrecipient, message, subject);
                }                   

            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure SendEmailMessageNonFatalError()" + ex.Message);
                _logger.exception(ex);
                throw new Exception(ex.Message);
            }
        }
        private void SendEmailProcessCompletedUnsuccessfully()
        {
            var recipient = _provider.Recipient;
            var myList = new List<string>();
            myList.Add(recipient);
            string[] arrayrecipient = myList.ToArray();
            string subject = "TrackerLogbatchReport Completed Unsuccessfully";
            StringBuilder messageBuilder = new StringBuilder();
            try
            {
                foreach (WorkItem workItem in ProcessCompletedUnsuccessfullyList)
                {
                    messageBuilder.AppendLine($"Application ID: {workItem.ApplicationID} Application Name: {workItem.AplicationName} Date: {workItem.Date.ToString("yyyy-MM-dd")} Time: {workItem.Time.TimeOfDay} Job tracker TypeID: {workItem.TypeID} Fatal Error Application Message: {workItem.Message}").Append(Environment.NewLine);
                    //message += "Application ID: " + workItem.ApplicationID + " Aplication Name: " + workItem.AplicationName + " Date: " + workItem.Date.ToString("yyyy-MM-dd") + " Time: " + workItem.Time.TimeOfDay + " Job tracker TypeID: " + workItem.TypeID + " Fatal Error Application Message: " + workItem.Message + "\n"; ;

                }
                string message = messageBuilder.ToString();
                if (arrayrecipient != null && arrayrecipient.Any() && !string.IsNullOrWhiteSpace(message) && !string.IsNullOrWhiteSpace(subject))
                {
                    emailsender.SendEmail(arrayrecipient, message, subject);
                }
            }

            catch (Exception ex)
            {
                _logger.logger("Generic exception failure ProcessCompletedUnsuccessfully()" + ex.Message);
                _logger.exception(ex);
                throw new Exception(ex.Message);
            }
        }
        private void SendEmailMessageDelayed()
        {
            var recipient = _provider.Recipient;
            var myList = new List<string>();
            myList.Add(recipient);
            string[] arrayrecipient = myList.ToArray();
            string subject = "TrackerLogbatchReport Delayed or unfinished Jobs";
            StringBuilder messageBuilder = new StringBuilder();

            try
            {
                foreach (WorkItem workItem in DelayedWorkItemsList)
                {
                    messageBuilder.AppendLine($"Application ID: {workItem.ApplicationID} Application Name: {workItem.AplicationName} Date: {workItem.Date.ToString("yyyy-MM-dd")} Time: {workItem.Time.TimeOfDay} Job tracker TypeID: {workItem.TypeID} Fatal Error Application Message: {workItem.Message}").Append(Environment.NewLine);
                    //message += "Application ID: "+ workItem.ApplicationID + " Aplication Name: " + workItem.AplicationName + " Date: " + workItem.Date.ToString("yyyy-MM-dd") + " Time: " + workItem.Time.TimeOfDay + " Job tracker TypeID: " + workItem.TypeID + " Fatal Error Application Message: " + workItem.Message + "\n"; ;

                }
                string message = messageBuilder.ToString();
                if (arrayrecipient != null && arrayrecipient.Any() && !string.IsNullOrWhiteSpace(message) && !string.IsNullOrWhiteSpace(subject))
                {
                    emailsender.SendEmail(arrayrecipient, message, subject);

                }

            }
            catch (Exception ex)
            {
                _logger.logger("Generic exception failure SendEmailMessageFatalError()" + ex.Message);
                _logger.exception(ex);
                throw new Exception(ex.Message);
            }
        }

    }


}
